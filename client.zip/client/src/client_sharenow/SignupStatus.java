package client_sharenow;

public enum SignupStatus {
    SUCCESS("0"),FAILED("-1");

    SignupStatus(String s){
        this.toString();
    }
}