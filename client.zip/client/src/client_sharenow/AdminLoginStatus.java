package client_sharenow;

public enum AdminLoginStatus {
        SUCCESS("0"),FAILED("1");
        AdminLoginStatus(String s){
            s.toString();
        }
}
