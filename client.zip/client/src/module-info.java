module client_sharenow {
    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.controls;
    requires javafx.base;
    requires jaxb.api.osgi;

    opens client_sharenow;

}